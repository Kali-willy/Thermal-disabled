#!/system/bin/sh
# Universal Thermal Throttling Disabler
# Author: willygailo01@gmail.com

# Restore original thermal configuration from backup if available
MODDIR=${0%/*}

if [ -d "$MODDIR/backup/vendor/etc/thermal" ]; then
  mkdir -p /system/vendor/etc
  cp -rf $MODDIR/backup/vendor/etc/thermal /system/vendor/etc/
fi

if [ -d "$MODDIR/backup/etc/thermal" ]; then
  mkdir -p /system/etc
  cp -rf $MODDIR/backup/etc/thermal /system/etc/
fi

# Restart thermal services
start thermal-engine 2>/dev/null
start thermald 2>/dev/null
start thermal_manager 2>/dev/null
start mi_thermald 2>/dev/null
start thermal_watcher 2>/dev/null
start thermal-hal-1-0 2>/dev/null
start thermal-hal-2-0 2>/dev/null

# Set SELinux context if needed
if [ -d "/system/vendor/etc/thermal" ]; then
  chcon -R u:object_r:vendor_configs_file:s0 /system/vendor/etc/thermal
fi

if [ -d "/system/etc/thermal" ]; then
  chcon -R u:object_r:system_file:s0 /system/etc/thermal
fi 