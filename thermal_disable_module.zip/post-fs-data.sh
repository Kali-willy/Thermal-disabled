#!/system/bin/sh
# Universal Thermal Throttling Disabler
# Author: willygailo01@gmail.com

MODDIR=${0%/*}

# Create needed directories
mkdir -p $MODDIR/system/vendor/etc
mkdir -p $MODDIR/system/etc

# Backup original thermal configuration (if exists and not already backed up)
if [ -d "/system/vendor/etc/thermal" ] && [ ! -d "$MODDIR/backup/vendor/etc/thermal" ]; then
  mkdir -p $MODDIR/backup/vendor/etc
  cp -rf /system/vendor/etc/thermal $MODDIR/backup/vendor/etc/
fi

if [ -d "/system/etc/thermal" ] && [ ! -d "$MODDIR/backup/etc/thermal" ]; then
  mkdir -p $MODDIR/backup/etc
  cp -rf /system/etc/thermal $MODDIR/backup/etc/
fi

# Now we create empty thermal configuration to disable thermal services
# This handles devices that use thermal configuration files
mkdir -p $MODDIR/system/vendor/etc/thermal
mkdir -p $MODDIR/system/etc/thermal

# Set SELinux context
if [ -d "$MODDIR/system/vendor/etc/thermal" ]; then
  chcon -R u:object_r:vendor_configs_file:s0 $MODDIR/system/vendor/etc/thermal
fi

if [ -d "$MODDIR/system/etc/thermal" ]; then
  chcon -R u:object_r:system_file:s0 $MODDIR/system/etc/thermal
fi 