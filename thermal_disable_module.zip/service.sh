#!/system/bin/sh
# Universal Thermal Throttling Disabler
# Author: willygailo01@gmail.com

MODDIR=${0%/*}

# Wait until boot is complete
while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 1
done

# Log file
LOG_FILE=$MODDIR/thermal_disable.log
touch $LOG_FILE
echo "Thermal Throttling Disabler started at $(date)" > $LOG_FILE

# Function to disable thermal services
disable_thermal() {
  # Stop thermal services
  stop thermal-engine 2>> $LOG_FILE
  stop thermald 2>> $LOG_FILE
  stop thermal_manager 2>> $LOG_FILE
  stop mi_thermald 2>> $LOG_FILE
  stop thermal_watcher 2>> $LOG_FILE
  stop thermal-hal-1-0 2>> $LOG_FILE
  stop thermal-hal-2-0 2>> $LOG_FILE
  
  # Try to disable thermal through sysfs for different OEMs
  # Common thermal nodes
  thermal_nodes=(
    "/sys/class/thermal/thermal_zone"
    "/sys/devices/virtual/thermal/thermal_zone"
    "/sys/devices/virtual/thermal"
    "/sys/module/msm_thermal"
    "/sys/kernel/debug/msm_thermal"
    "/system/vendor/etc/thermal"
  )
  
  # Set maximum values or disable thermal nodes
  for base_node in "${thermal_nodes[@]}"; do
    if [ -d "$base_node" ]; then
      echo "Processing $base_node" >> $LOG_FILE
      
      # Disable all thermal zones if they exist
      if [ -d "$base_node" ] && [[ "$base_node" == *"thermal_zone"* ]]; then
        for zone in "$base_node"*; do
          if [ -f "$zone/mode" ]; then
            echo "disabled" > "$zone/mode" 2>> $LOG_FILE
          fi
          
          if [ -f "$zone/trip_point_0_temp" ]; then
            echo "100000" > "$zone/trip_point_0_temp" 2>> $LOG_FILE
          fi
          
          if [ -f "$zone/trip_point_1_temp" ]; then
            echo "100000" > "$zone/trip_point_1_temp" 2>> $LOG_FILE
          fi
        done
      fi
    fi
  done
  
  # Disable specific OEM thermal services and settings
  
  # Infinix/Transsion
  if [ -f "/sys/transsion/thermal/scenario" ]; then
    echo "0" > /sys/transsion/thermal/scenario 2>> $LOG_FILE
  fi
  
  # Samsung
  if [ -f "/sys/devices/platform/battery/power_supply/battery/wc_control" ]; then
    echo "0" > /sys/devices/platform/battery/power_supply/battery/wc_control 2>> $LOG_FILE
  fi
  
  # Xiaomi/Redmi
  if [ -f "/sys/class/thermal/thermal_message/sconfig" ]; then
    echo "0" > /sys/class/thermal/thermal_message/sconfig 2>> $LOG_FILE
  fi
  
  # Qualcomm devices (Snapdragon)
  if [ -d "/sys/module/msm_thermal" ]; then
    if [ -f "/sys/module/msm_thermal/parameters/enabled" ]; then
      echo "N" > /sys/module/msm_thermal/parameters/enabled 2>> $LOG_FILE
    fi
    if [ -f "/sys/module/msm_thermal/core_control/enabled" ]; then
      echo "0" > /sys/module/msm_thermal/core_control/enabled 2>> $LOG_FILE
    fi
  fi
  
  # MediaTek devices
  if [ -f "/proc/driver/thermal/tzbts_param" ]; then
    echo "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0" > /proc/driver/thermal/tzbts_param 2>> $LOG_FILE
  fi
  
  # Huawei
  if [ -f "/sys/class/hw_power/charger/direct_charger/iin_thermal" ]; then
    echo "10000" > /sys/class/hw_power/charger/direct_charger/iin_thermal 2>> $LOG_FILE
  fi
  
  # Realme/OPPO
  if [ -f "/sys/kernel/thermal/tp_thermal_control" ]; then
    echo "0" > /sys/kernel/thermal/tp_thermal_control 2>> $LOG_FILE
  fi
  
  # Vivo
  if [ -f "/sys/class/power_supply/battery/input_suspend" ]; then
    echo "0" > /sys/class/power_supply/battery/input_suspend 2>> $LOG_FILE
  fi
}

# Main
disable_thermal
echo "Thermal throttling disabled at $(date)" >> $LOG_FILE

# Keep running the disable function every 5 minutes to prevent thermal services from restarting
while true; do
  sleep 300
  disable_thermal
  echo "Thermal throttling re-disabled at $(date)" >> $LOG_FILE
done 